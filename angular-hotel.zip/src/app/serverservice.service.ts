import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ServerserviceService {
  _rootURL = "http://localhost:3000/"

  constructor(public http: HttpClient) { }

  userlogin(formdata) {
    return this.http.post(this._rootURL + 'userverify/', formdata);
  }
  registerUser(fromdata){
    return this.http.post(this._rootURL+"users/",fromdata);
  }
  getHotelbyId(token){
    return this.http.get(this._rootURL+'getHotelById/',token);
  }
  getHotelbyPlace(token){
    return this.http.get(this._rootURL+'getHotelByPlace/'+token);
  }
  getAllHotel(){
    return this.http.get(this._rootURL+'hotels/');
  }
  
}
