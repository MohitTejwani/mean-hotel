import { Component } from '@angular/core';
import { ServerserviceService } from './serverservice.service';
import { NgForm } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { Router} from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('expandani', [
      state(
        'show',
        style({
          opacity: 1,
          zIndex: '9999',
          transform: 'scale(1)'
        })
      ),
      state(
        'hide',
        style({
          opacity: 0,
          zIndex: '-9999',
          transformOrigin: 'center top',
          transform: 'scale(0)'
        })
      ),
      transition('show <=> hide', animate('500ms linear')),
    ])
  ]
})
export class AppComponent {
  token: any;
  hotelData = [];
  name: any;
  flag = 1;
  _showuplodephoto = false;

  constructor(public server: ServerserviceService, public router:Router) { }

  ngOnInit() {
    this.server.getAllHotel().subscribe((res: any) => {

      for (let i = 0; i < res.length; i++) {
        this.hotelData.push(res[i]);
      }
      console.log(this.hotelData);
      this.name = this.hotelData[0].hotelName;
    })
  }
  userLogin(allformdata) {
    localStorage.removeItem('usertoken');
    console.log(allformdata.value);
    this.server.userlogin(allformdata.value).subscribe((res: any) => {
      console.log(res);
      this.token = localStorage.setItem('usertoken', JSON.stringify(res));
      this.router.navigate(['/test'])
    })
  }
  createUser(allformdata) {
    console.log(allformdata.value);
    this.server.registerUser(allformdata.value).subscribe((res: any) => {
      console.log(res);
      if (res > 0) {
        this.flag = 1;
      } else {
        this.flag = 0;
      }
    })
  }
  getHotel(allformdata: any) {

    this.hotelData = [];
    this.server.getHotelbyPlace(allformdata.value.place).subscribe((res: any) => {
      for (let i = 0; i < res.length; i++) {
        this.hotelData.push(res[i]);
      }
      console.log(this.hotelData);

    })
  }
  booking(hsid) {
    if (localStorage.getItem('usertoken') == null) {

    }
  }
  signup() {
    this.flag = 0;
  }
  signin() {
    this.flag = 1;
  }
}

