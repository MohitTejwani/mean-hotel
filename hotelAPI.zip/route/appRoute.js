'use strict';
module.exports = function (app) {
  var userList = require('../controller/userController');
  var hotelList = require('../controller/hotelController');
  // default route
  app.get('/', function (req, res) {
    return res.send({ error: true, message: 'hello ' })
  });



  // User Routes
  app.route('/users')
    .post(userList.create_a_user);

  // User Verification 
  app.route('/userverify/')
    .post(userList.user_verify);

 // Hotel Routes
  app.route('/hotels')
    .get(hotelList.list_all_Hotel);
 // Hotel By Id 
    app.route('/getHotelById/:hotelId')
        .get(hotelList.read_a_hotelById);
 // Hotel By Place 
    app.route('/getHotelByPlace/:place')
        .get(hotelList.read_a_HotelByPlace);  
};
