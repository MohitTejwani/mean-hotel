var express = require('express');
var app = express();
bodyParser = require('body-parser');
port = process.env.port || 3000;


const mysql = require('mysql');
// connection configurations
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'admin',
    password: '12345',
    database: 'hotelDB'
});

// connect to database
mc.connect();

// 
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

app.listen(port);

console.log('API server started on: ' + port);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var routes = require('./route/appRoute'); //importing route
routes(app); //register the route