var sql = require('../db');
//User object constructor
var User = function (user) {
    this.name = user.name;
    this.contact = user.contact;
    this.password = user.password;
};

//  Create New User
User.createUser = function (newUser, result) {
    sql.query("INSERT INTO user set ?", newUser, function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });
};

// Login User 

User.login = function (contact, password, result) {
    sql.query("select * from user where contact = ? AND password = ? ", [contact, password], function (err, res) {
        if (err) {
            console("error : Invalid Contact Password")
            resizeTo(null, err);
        } else {
            result(null, res);
        }
    })
}

module.exports = User;