var sql = require('../db');
//Hotel object constructor
var Hotel = function (hotel) {
    this.availabel = hotel.availabel;
};
Hotel.getAllHotel = function (result) {
    sql.query("SELECT * FROM hotelSeats LEFT JOIN hotel ON hotelSeats.hid = hotel.hid", function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            console.log('Hotel : ', res);

            result(null, res);
        }
    });
};

Hotel.getHotelById = function (hotelid, result) {
    sql.query("SELECT * FROM hotelSeats JOIN hotel ON hotelSeats.hid = hotel.hid AND hotel.hid = ? ", hotelid, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res);

        }
    });
};


Hotel.getHotelByPlace = function (hotelplace, result) {
    sql.query("SELECT * FROM hotelSeats JOIN hotel ON hotelSeats.hid = hotel.hid AND hotel.place=?", hotelplace, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res);

        }
    });
};

module.exports = Hotel;