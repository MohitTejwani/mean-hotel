'use strict';

var User = require('../model/userModel');


// Create New User
exports.create_a_user = function (req, res) {
    var new_user = new User(req.body);
  
    //handles null error 
    if (!new_user.name || !new_user.contact || !new_user.password) {
  
      res.status(400).send({ error: true, message: 'Please provide name/email/password' });
  
    }
    else {
  
      User.createUser(new_user, function (err, user) {
  
        if (err)
          res.send(err);
        res.json(user);
      });
    }
  };


exports.user_verify = function (req, res) {
    User.login(req.body.contact, req.body.password, function (err, user) {
      if (err) {
        res.send(err);
      } else {
        
        if (Object.keys(user).length === 0) {
          res.json({ message: "Invalid Username Password" });
        } else {
          res.json({ message: "Login Succesfully " })
        }
      }
    })
  }
  
  