'use strict';

var Hotel = require('../model/hotelModel');

// Get All Hotel Details 
exports.list_all_Hotel = function (req, res) {
  Hotel.getAllHotel(function (err, hotel) {

    console.log('controller')
    if (err)
      res.send(err);
    console.log('res', hotel);
    res.send(hotel);
  });
};


// Get Hotel Detail By UserId
exports.read_a_hotelById = function (req, res) {
    console.log("Hello",req.params.hotelId);
    Hotel.getHotelById(req.params.hotelId, function (err, hotel) {
        if (err)
          res.send(err);
        res.json(hotel);
      });
    };


// Get Hotel Place By UserId
exports.read_a_HotelByPlace = function (req, res) {
    Hotel.getHotelByPlace(req.params.place, function (err, hotel) {
        if (err)
          res.send(err);
        res.json(hotel);
      });
    };
